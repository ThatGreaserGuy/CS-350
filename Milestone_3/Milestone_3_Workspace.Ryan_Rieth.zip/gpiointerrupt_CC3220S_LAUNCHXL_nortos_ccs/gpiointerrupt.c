/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/* Timer configuration */
#include <ti/drivers/Timer.h>

/* Set TimerFlag to 0 */
volatile unsigned char TimerFlag = 0;

/* Enum for state machine */
enum SM_STATES {
    SM_Start,
    SM_S,
    SM_O,
    SM_SS,
    SM_K,
    SM_Pause
} SM_STATE;

/* Global variables for system mode switching */
unsigned char ButtonClick = 0;
unsigned char MorseToggle = 0;

/*
 * ======== CONFIG_TIMER_0 ========
 * Callback function for the timer.
 *
 * Code was given via lab guide.
 */
void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    TimerFlag = 1;                                  // Raise a timer flag
}

/*
 * ======== CONFIG_TIMER_0 ========
 * Initialize timer.
 *
 * Code was given via lab guide.
 */
void initTimer(void)
{
    Timer_Handle timer0;
    Timer_Params params;
    Timer_init();
    Timer_Params_init(&params);

    params.period = 500000;                         // Per instructions, changed to 500000 us (half a second, GCD)
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);

    /* Failed to initialize timer */
    if (timer0 == NULL) { while(1){} }

    /* Failed to start timer */
    if (Timer_start(timer0) == Timer_STATUS_ERROR) { while(1){} }
}

/*
 * ======== TickFct_Morse() ========
 * Toggle between SOS and OK along the timer.
 */
void TickFct_Morse() {
    static unsigned char count;

    /* Transitional switch statement */
    switch(SM_STATE) {
        case SM_Start:
            count = 0;
            SM_STATE = SM_S;
            break;

        case SM_S:
            if (!(count < 8)) {             // If the first "S" has blinked
                count = 0;
                SM_STATE = SM_O;
            }
            break;

        case SM_O:
            if (!(count < 14)) {            // If the "O" has blinked
                count = 0;
                if (MorseToggle) { SM_STATE = SM_K; } else { SM_STATE = SM_SS; }
            }
            break;

        case SM_SS:
            if (!(count < 5)) {             // If the second "S" has blinked
                count = 0;
                SM_STATE = SM_Pause;
            }
            break;

        case SM_K:
            if (!(count < 9)) {             // If the "K" has blinked
                count = 0;
                SM_STATE = SM_Pause;
            }
            break;

        case SM_Pause:
            if (!(count < 7)) {             // If the pause period has passed, determine which message to blink next
                count = 0;
                if (MorseToggle) { SM_STATE = SM_O; } else { SM_STATE = SM_S; }
            }
            break;

        default:
            SM_STATE = SM_Start;            // By default, start the Morse code message blinking
            break;
    }

    /* Main switch statement */
    switch(SM_STATE) {
        case SM_Start:
            break;

        /* Blink the first letter "S" in "SOS" */
        case SM_S:
            if (count == 0 || count == 2 || count == 4) { GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON); }
            else { GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF); }
            count++;
            break;

        /* Blink the letter "O" in either "SOS" or "OK" */
        case SM_O:
            if ((count < 3) || (count > 3 && count < 7) || (count > 7 && count < 11)) { GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON); }
            else { GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF); }
            count++;
            break;

        /* Blink the second letter "S" in "SOS" */
        case SM_SS:
            if (count == 0 || count == 2 || count == 4) { GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON); }
            else { GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF); }
            count++;
            break;

        /* Blink the letter "K" in "OK" */
        case SM_K:
            if (count < 3 || count > 5) { GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON); }
            else { GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF); }

            if (count == 4) { GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON); }
            else { GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF); }
            count++;
            break;

        /* Initiate the pause period between repeated message or other message */
        case SM_Pause:
            if (count == 0) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
            } else if (count == 6) {
                if (ButtonClick) {
                    MorseToggle = !MorseToggle;             // Toggle the other message if either button has been pressed
                    ButtonClick = 0;
                }
            }
            count++;
            break;

        default:
            break;
    }
}

/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *  Switches the Morse code message from "SOS" to "OK".
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index) { ButtonClick = 1; }

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  Performs the same action as gpioButtonFxn0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index) { ButtonClick = 1; }

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callbacks */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);
    GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_1);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    /* Begin with both LEDs off for clean slate message delivery */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);

    /* Initiate the state machine in its default starting mode */
    SM_STATE = SM_Start;

    initTimer();
    while(1){
        TickFct_Morse();
        while(!TimerFlag){}
        TimerFlag = 0;
    }
}
